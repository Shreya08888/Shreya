package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView input,output;
    private String i,o,newOutput;
    private Button btn0,btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9,clear,power,percent,division,
            mul,sub,add,point,equal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        input=findViewById(R.id.input);
        output=findViewById(R.id.output);
        btn0=findViewById(R.id.btn0);
        btn1=findViewById(R.id.btn1);
        btn2=findViewById(R.id.btn2);
        btn3=findViewById(R.id.btn3);
        btn4=findViewById(R.id.btn4);
        btn5=findViewById(R.id.btn5);
        btn6=findViewById(R.id.btn6);
        btn7=findViewById(R.id.btn7);
        btn8=findViewById(R.id.btn8);
        btn9=findViewById(R.id.btn9);
        clear=findViewById(R.id.clear);
        power=findViewById(R.id.power);
        percent=findViewById(R.id.percent);
        division=findViewById(R.id.division);
        mul=findViewById(R.id.mul);
        sub=findViewById(R.id.sub);
        add=findViewById(R.id.add);
        point=findViewById(R.id.point);
        equal=findViewById(R.id.equal);
    }
    public void  onButtonClicked(View view){
        Button button=(Button) view;
        String data=button.getText().toString();
        switch (data){
            case "AC":
                i=null;
                o=null;
                newOutput=null;
                output.setText("");
                break;
            case "^":
                solve();
                i+="^";
                break;
            case "*":
                solve();
                i+="*";
                break;
            case "=":
                solve();
                break;
            case "%":
                i+="%";
                double d= Double.parseDouble(input.getText().toString())/100;
                output.setText(String.valueOf(d));
                break;
            default:
                if(i==null){
                    i= "";
                }
                if(data.equals("+")|| data.equals("/")||data.equals("-")){
                    solve();
                }
                i+=data;
        }
        input.setText(i);
    }
    private void solve(){
        if (i.split("\\+").length==2){
            String numbers[]=i.split("\\+");
            try {
                double d=Double.parseDouble(numbers[0])+Double.parseDouble(numbers[1]);
                o=Double.toString(d);
                newOutput=cutDecimal(o);
                output.setText(newOutput);
                i=d +"";
            }
            catch (Exception e){
                output.setError(e.getMessage().toString());
            }
        }
        if (i.split("\\*").length==2){
            String numbers[]=i.split("\\*");
            try {
                double d=Double.parseDouble(numbers[0])*Double.parseDouble(numbers[1]);
                o=Double.toString(d);
                newOutput=cutDecimal(o);
                output.setText(newOutput);
                i=d +"";
            }
            catch (Exception e){
                output.setError(e.getMessage().toString());
            }
        }
        if (i.split("\\/").length==2){
            String numbers[]=i.split("\\/");
            try {
                double d=Double.parseDouble(numbers[0])/Double.parseDouble(numbers[1]);
                o=Double.toString(d);
                newOutput=cutDecimal(o);
                output.setText(newOutput);
                i=d +"";
            }
            catch (Exception e){
                output.setError(e.getMessage().toString());
            }
        }
        if (i.split("\\^").length==2){
            String numbers[]=i.split("\\^");
            try {
                double d=Math.pow(Double.parseDouble(numbers[0]),Double.parseDouble(numbers[1]));
                o=Double.toString(d);
                newOutput=cutDecimal(o);
                output.setText(newOutput);
                i=d +"";
            }
            catch (Exception e){
                output.setError(e.getMessage().toString());
            }

        }
        if (i.split("\\-").length==2){
            String numbers[]=i.split("\\-");
            try {
                if(Double.parseDouble(numbers[0])<Double.parseDouble(numbers[1])){
                    double d=Double.parseDouble(numbers[1])-Double.parseDouble(numbers[0]);
                    o=Double.toString(d);
                    newOutput=cutDecimal(o);
                    output.setText("-"+newOutput);
                    i=d +"";

                }
                else {
                    double d=Double.parseDouble(numbers[0])-Double.parseDouble(numbers[1]);
                    o=Double.toString(d);
                    newOutput=cutDecimal(o);
                    output.setText(newOutput);
                    i=d +"";

                }

            }
            catch (Exception e){
                output.setError(e.getMessage().toString());
            }
        }

    }
    private  String cutDecimal(String number){
        String n[]=number.split("\\+");
        if(n.length>1){
            if(n[1].equals("0")){
                number=n[0];
            }
        }
        return  number;
    }

}